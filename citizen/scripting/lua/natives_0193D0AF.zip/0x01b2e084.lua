function Global.SetPedDropsWeapon(ped)
	return _in(0x6B7513D9966FBEC0, ped)
end
