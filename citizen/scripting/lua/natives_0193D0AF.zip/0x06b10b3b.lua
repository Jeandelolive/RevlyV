function Global.N_0xbb0527ec6341496d()
	return _in(0xBB0527EC6341496D, _r, _ri)
end
