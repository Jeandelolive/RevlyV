function Global.N_0x9fe5633880ecd8ed(p0, p1, p2, p3)
	return _in(0x9FE5633880ECD8ED, p0, p1, p2, p3)
end
