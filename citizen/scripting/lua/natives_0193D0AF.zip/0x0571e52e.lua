function Global.N_0x0218ba067d249dea()
	return _in(0x0218BA067D249DEA)
end
