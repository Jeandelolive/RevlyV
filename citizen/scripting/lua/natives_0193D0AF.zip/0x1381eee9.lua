function Global.NetworkIsPartyMember(networkHandle)
	return _in(0x676ED266AADD31E0, _ii(networkHandle) --[[ may be optional ]], _r)
end
