function Global.SetAggressiveHorns(toggle)
	return _in(0x395BF71085D1B1D9, toggle)
end
