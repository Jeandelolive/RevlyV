function Global.FindAnimEventPhase(animDictionary, animName, p2)
	return _in(0x07F1BE2BCCAA27A7, _ts(animDictionary), _ts(animName), _ts(p2), _i, _i, _r)
end
