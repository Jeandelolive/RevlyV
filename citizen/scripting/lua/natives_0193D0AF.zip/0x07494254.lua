function Global.N_0xa9240a96c74cca13(p0)
	return _in(0xA9240A96C74CCA13, p0, _r)
end
