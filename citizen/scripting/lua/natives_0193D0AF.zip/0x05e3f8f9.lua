function Global.SetPlayerSimulateAiming(player, toggle)
	return _in(0xC54C95DA968EC5B5, player, toggle)
end
