function Global.GetPlayerCurrentStealthNoise(player)
	return _in(0x2F395D61F3A1F877, player, _r, _rf)
end
