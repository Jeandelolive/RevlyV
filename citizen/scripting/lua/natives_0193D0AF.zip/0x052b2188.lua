function Global.StatSetFloat(statName, value, save)
	return _in(0x4851997F37FE9B3C, _ch(statName), value, save, _r)
end
