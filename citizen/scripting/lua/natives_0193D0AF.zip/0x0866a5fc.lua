function Global.GetPlayerMaxArmour(player)
	return _in(0x92659B4CE1863CB3, player, _r, _ri)
end
