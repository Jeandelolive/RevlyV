function Global.SetAllVehicleGeneratorsActiveInArea(x1, y1, z1, x2, y2, z2, p6, p7)
	return _in(0xC12321827687FE4D, x1, y1, z1, x2, y2, z2, p6, p7)
end
