function Global.N_0x3d42b92563939375(p0)
	return _in(0x3D42B92563939375, _ts(p0), _r)
end
