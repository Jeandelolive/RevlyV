function Global.VehicleWaypointPlaybackOverrideSpeed(p0, p1)
	return _in(0x121F0593E0A431D7, p0, p1)
end
