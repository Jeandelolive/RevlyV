function Global.N_0x9614b71f8adb982b()
	return _in(0x9614B71F8ADB982B, _r, _ri)
end
