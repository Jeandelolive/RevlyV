function Global.Absi(value)
	return _in(0xF0D31AD191A74F87, value, _r, _ri)
end
