function Global.N_0xc64ded7ef0d2fe37(p0)
	return _in(0xC64DED7EF0D2FE37, _ii(p0) --[[ may be optional ]], _r, _ri)
end
