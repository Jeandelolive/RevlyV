function Global.N_0xdb34e8d56fc13b08(p0, p1, p2)
	return _in(0xDB34E8D56FC13B08, p0, p1, p2)
end
