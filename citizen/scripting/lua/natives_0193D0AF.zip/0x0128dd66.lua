function Global.N_0x5d2bfaab8d956e0e()
	return _in(0x5D2BFAAB8D956E0E)
end
