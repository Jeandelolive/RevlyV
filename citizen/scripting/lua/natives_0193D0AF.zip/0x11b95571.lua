function Global.SetPlayerAngry(playerPed, disabled)
	return _in(0xEA241BB04110F091, playerPed, disabled)
end
