function Global.N_0xc55854c7d7274882()
	return _in(0xC55854C7D7274882)
end
