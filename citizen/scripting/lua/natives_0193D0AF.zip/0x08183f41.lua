function Global.ScInboxMessagePush(p0)
	return _in(0x9A2C8064B6C1E41A, p0, _r)
end
