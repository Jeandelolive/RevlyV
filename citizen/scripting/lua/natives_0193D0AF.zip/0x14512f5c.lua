function Global.N_0x5ff2c33b13a02a11(p0)
	return _in(0x5FF2C33B13A02A11, p0)
end
