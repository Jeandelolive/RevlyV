function Global.GetTvVolume()
	return _in(0x2170813D3DD8661B, _r, _rf)
end
