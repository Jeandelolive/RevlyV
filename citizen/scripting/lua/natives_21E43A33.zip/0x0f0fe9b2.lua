function Global.NetworkGetFoundGamer(p1)
	return _in(0x9DCFF2AFB68B3476, _i, p1, _r)
end
