function Global.SetHdArea(p0, p1, p2, p3)
	return _in(0xB85F26619073E775, p0, p1, p2, p3)
end
