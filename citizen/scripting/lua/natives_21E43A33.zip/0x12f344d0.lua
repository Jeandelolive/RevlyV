function Global.SetVehicleDoorControl(vehicle, doorIndex, p2, p3)
	return _in(0xF2BFA0430F0A0FCB, vehicle, doorIndex, p2, p3)
end
