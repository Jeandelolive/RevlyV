function Global.StartParticleFxNonLoopedOnEntity(effectName, entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, p9, p10, p11)
	return _in(0x0D53A3B8DA0809D2, _ts(effectName), entity, xOffset, yOffset, zOffset, xRot, yRot, zRot, scale, p9, p10, p11, _r)
end
