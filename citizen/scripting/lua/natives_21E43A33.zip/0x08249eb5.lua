function Global.RemoveAllPickupsOfType(p0)
	return _in(0x27F9D613092159CF, p0)
end
