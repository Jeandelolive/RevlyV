function Global.IsPlayerRidingTrain(player)
	return _in(0x4EC12697209F2196, player, _r)
end
