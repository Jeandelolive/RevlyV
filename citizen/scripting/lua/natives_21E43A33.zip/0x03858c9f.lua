function Global.CreateIncident(x, y, z, radius)
	return _in(0x3F892CAF67444AE7, _i, x, y, z, _i, radius, _i, _r)
end
