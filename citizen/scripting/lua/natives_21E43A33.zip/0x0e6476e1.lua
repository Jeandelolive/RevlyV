function Global.NetworkHasControlOfPickup(p0)
	return _in(0x5BC9495F0B3B6FA6, p0, _r)
end
