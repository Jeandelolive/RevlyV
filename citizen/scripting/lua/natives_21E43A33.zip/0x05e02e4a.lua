function Global.N_0xb51b9ab9ef81868c(p0)
	return _in(0xB51B9AB9EF81868C, p0)
end
