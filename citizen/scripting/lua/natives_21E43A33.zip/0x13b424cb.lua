function Global.N_0x6f697a66ce78674e(p0, p1)
	return _in(0x6F697A66CE78674E, p0, p1)
end
