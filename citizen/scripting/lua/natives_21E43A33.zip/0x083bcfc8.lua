function Global.SetPtfxAssetNextCall(name)
	return _in(0x6C38AF3693A69A91, _ts(name))
end
