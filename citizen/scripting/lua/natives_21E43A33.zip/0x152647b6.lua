function Global.GetCutsceneTime()
	return _in(0xE625BEABBAFFDAB9, _r, _ri)
end
