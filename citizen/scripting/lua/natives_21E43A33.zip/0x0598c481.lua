function Global.ResetPedInVehicleContext(p0)
	return _in(0x22EF8FF8778030EB, p0)
end
