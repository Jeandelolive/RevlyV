function Global.N_0x346ef3ecaaab149e()
	return _in(0x346EF3ECAAAB149E)
end
