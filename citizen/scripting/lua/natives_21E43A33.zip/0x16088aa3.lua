function Global.N_0x0c1c5d756fb5f337(p0)
	return _in(0x0C1C5D756FB5F337, _ii(p0) --[[ may be optional ]], _r)
end
