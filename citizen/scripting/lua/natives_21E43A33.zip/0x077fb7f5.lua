function Global.RollDownWindows(vehicle)
	return _in(0x85796B0549DDE156, vehicle, _r, _ri)
end
