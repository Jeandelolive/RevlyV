function Global.SetScenarioPedsSpawnInSphereArea(p0, p1, p2, p3, p4)
	return _in(0x28157D43CF600981, p0, p1, p2, p3, p4)
end
