function Global.DisplayHud(Toggle)
	return _in(0xA6294919E56FF02A, Toggle, _r, _ri)
end
