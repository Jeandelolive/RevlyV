function Global.NetworkPlayerIsCheater()
	return _in(0x655B91F1495A9090, _r, _ri)
end
