function Global.GetAnimInitialOffsetPosition(p2, p3, p4, p5, p6, p7, p8, p9)
	return _in(0xBE22B26DD764C040, _i, _i, p2, p3, p4, p5, p6, p7, p8, p9, _r, _rv)
end
