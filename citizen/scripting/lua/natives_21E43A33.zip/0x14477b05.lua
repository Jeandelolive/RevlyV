function Global.N_0x5bff36d6ed83e0ae()
	return _in(0x5BFF36D6ED83E0AE, _r, _rv)
end
