function Global.SetTextGxtEntry(entry)
	return _in(0x521FB041D93DD0E4, _ts(entry))
end
