function Global.TaskSynchronizedScene(p0, scene, animDictionary, animationName, p4, p5, p6, p7, p8, p9)
	return _in(0xEEA929141F699854, p0, scene, _ts(animDictionary), _ts(animationName), p4, p5, p6, p7, p8, p9)
end
