function Global.N_0x8b6a4dd0af9ce215(p0, p1)
	return _in(0x8B6A4DD0AF9CE215, p0, p1)
end
