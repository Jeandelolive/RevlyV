function Global.N_0x2b3a8f7ca3a38fde()
	return _in(0x2B3A8F7CA3A38FDE)
end
