function Global.SetAiWeaponDamageModifier(value)
	return _in(0x1B1E2A40A65B8521, value)
end
