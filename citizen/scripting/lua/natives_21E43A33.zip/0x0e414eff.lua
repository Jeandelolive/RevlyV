function Global.IsSynchronizedSceneLooped(p0)
	return _in(0x62522002E0C391BA, p0, _r)
end
