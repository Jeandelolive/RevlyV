function Global.GetFrameTime()
	return _in(0x15C40837039FFAF7, _r, _rf)
end
