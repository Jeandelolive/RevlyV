function Global.IsControlPressed(index, control)
	return _in(0xF3A21BCD95725A4A, index, control, _r)
end
