function Global.N_0x419615486bbf1956(p0)
	return _in(0x419615486BBF1956, p0)
end
