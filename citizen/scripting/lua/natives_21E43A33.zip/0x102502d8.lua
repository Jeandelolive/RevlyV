function Global.IsAnyVehicleNearPoint(x, y, z, radius)
	return _in(0x61E1DD6125A3EEE6, x, y, z, radius, _r)
end
