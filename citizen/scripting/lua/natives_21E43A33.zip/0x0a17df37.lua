function Global.GetEventData(p0, eventIndex, p3)
	return _in(0x2902843FCD2B2D79, p0, eventIndex, _i, p3, _r)
end
