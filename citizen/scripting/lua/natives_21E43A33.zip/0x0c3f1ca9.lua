function Global.GetWeatherTypeTransition()
	return _in(0xF3BBE884A14BB413, _i, _i, _f)
end
