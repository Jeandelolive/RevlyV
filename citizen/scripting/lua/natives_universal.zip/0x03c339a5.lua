--- Parameters p0-p5 seems correct. The bool p6 is unknown, but through every X360 script it's always 1. Please correct p0-p5 if any prove to be wrong.
function Global.PointCamAtPedBone(cam, ped, boneIndex, x, y, z, p6)
	return _in(0x68B2B5F33BA63C41, cam, ped, boneIndex, x, y, z, p6)
end
