function Global.NetworkAddFriend(message)
	return _in(0x8E02D73914064223, _i, _ts(message), _r)
end
