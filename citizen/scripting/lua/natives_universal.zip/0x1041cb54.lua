--- Console Hash: 0x6C344AE3
-- "NETWORK_OVERRIDE_SEND_RESTRICTIONS" is right, but dev-c put a _ by default.
-- This is used alongside the native,
-- 'NETWORK_OVERRIDE_RECEIVE_RESTRICTIONS'. Read it's description for more info.
function Global.N_0x97dd4c5944cc2e6a(player, toggle)
	return _in(0x97DD4C5944CC2E6A, player, toggle)
end
