--- REQUEST_VEHICLE_*
function Global.N_0xdba3c090e3d74690(vehicle)
	return _in(0xDBA3C090E3D74690, vehicle)
end
