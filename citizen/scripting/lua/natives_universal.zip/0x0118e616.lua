--- Hash collision!
-- _IS_MP_GAMER_TAG_ACTIVE_2
function Global.AddTrevorRandomModifier(gamerTagId)
	return _in(0x595B5178E412E199, gamerTagId, _r)
end
