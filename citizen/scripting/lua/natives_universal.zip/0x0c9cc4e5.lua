function Global.SetEntityCollision(entity, toggle, keepPhysics)
	return _in(0x1A9205C1B9EE827F, entity, toggle, keepPhysics)
end
