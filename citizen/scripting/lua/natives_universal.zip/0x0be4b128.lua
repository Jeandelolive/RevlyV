--- Second Param = LiveryIndex
-- example
-- int count = VEHICLE::GET_VEHICLE_LIVERY_COUNT(veh);
-- for (int i = 0; i < count; i++)
-- {
-- char* LiveryName = VEHICLE::GET_LIVERY_NAME(veh, i);
-- }
-- this example will work fine to fetch all names
-- for example for Sanchez we get
-- SANC_LV1
-- SANC_LV2
-- SANC_LV3
-- SANC_LV4
-- SANC_LV5
-- Use _GET_LABEL_TEXT, to get the localized livery name.
-- -----------
-- NOTE: You may need to set the vehicle's modKit to 0 by using this function: SET_VEHICLE_MOD_KIT() before getting the name, otherwise this native may return NULL.
-- dev-c.com/nativedb/func/info/1f2aa07f00b3217a
function Global.GetLiveryName(vehicle, liveryIndex)
	return _in(0xB4C7A93837C91A1F, vehicle, liveryIndex, _r, _s)
end
