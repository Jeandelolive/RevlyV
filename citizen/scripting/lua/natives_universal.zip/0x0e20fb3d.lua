--- Quick disassembly and test seems to indicate that this native gets the Ped currently using the specified door.
function Global.N_0x218297bf0cfd853b(vehicle, doorIndex)
	return _in(0x218297BF0CFD853B, vehicle, doorIndex, _r, _ri)
end
