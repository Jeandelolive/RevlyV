function Global.N_0x052837721a854ec7(entity, flags1, flags2)
	return _in(0x052837721A854EC7, entity, flags1, flags2, _r, _ri)
end
