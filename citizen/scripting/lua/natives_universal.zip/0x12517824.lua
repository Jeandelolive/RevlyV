--- Returns the same as `IS_SOCIAL_CLUB_ACTIVE`.
function Global.IsOnlinePoliciesMenuActive()
	return _in(0x6F72CD94F7B5B68C, _r)
end
