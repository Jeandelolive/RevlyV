function Global.AppSaveData()
	return _in(0x95C5D356CDA6E85F)
end
