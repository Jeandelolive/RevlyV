--- This native only comes up once. And in that one instance, p1 is "1".
function Global.PlayVehicleDoorCloseSound(vehicle, p1)
	return _in(0x62A456AA4769EF34, vehicle, p1)
end
