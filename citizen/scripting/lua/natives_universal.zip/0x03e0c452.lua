function Global.HasCutsceneFinished()
	return _in(0x7C0A893088881D57, _r)
end
