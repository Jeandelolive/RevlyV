--- Makes a blip go small when off the minimap.
function Global.N_0x2b6d467dab714e8d(blip, toggle)
	return _in(0x2B6D467DAB714E8D, blip, toggle)
end
