--- formerly _REQUEST_STREAMED_SCRIPT
function Global.RequestStreamedScript(scriptHash)
	return _in(0xD62A67D26D9653E6, _ch(scriptHash))
end
