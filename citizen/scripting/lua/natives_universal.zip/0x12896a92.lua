function Global.N_0x6551b1f7f6cd46ea(p0)
	return _in(0x6551B1F7F6CD46EA, p0)
end
