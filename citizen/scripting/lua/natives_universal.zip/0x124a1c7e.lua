--- false = Any resolution < 1280x720
-- true = Any resolution >= 1280x720
function Global.GetIsHidef()
	return _in(0x84ED31191CC5D2C9, _r)
end
