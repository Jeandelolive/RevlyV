--- only documented params
-- dont know what this does.... To Be Continued...
function Global.N_0x163f8b586bc95f2a(coords, radius, modelHash, x, y, z, p7)
	return _in(0x163F8B586BC95F2A, coords, radius, _ch(modelHash), x, y, z, _v, p7, _r, _ri)
end
