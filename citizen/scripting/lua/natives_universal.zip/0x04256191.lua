--- Gets the number of instances of the specified script is currently running.
-- Actually returns numInstances - 1.
-- if (scriptPtr)
-- v3 = GetNumberOfInstancesOfScript(scriptPtr) - 1;
-- return v3;
function Global.GetNumberOfInstancesOfScriptWithNameHash(scriptHash)
	return _in(0x2C83A9DA6BFFC4F9, _ch(scriptHash), _r, _ri)
end
