function Global.HasPedGotWeaponComponent(ped, weaponHash, componentHash)
	return _in(0xC593212475FAE340, ped, _ch(weaponHash), _ch(componentHash), _r)
end
