function Global.NetworkIsThisScriptMarked(p0, p1, p2)
	return _in(0xD1110739EEADB592, p0, p1, p2, _r)
end
