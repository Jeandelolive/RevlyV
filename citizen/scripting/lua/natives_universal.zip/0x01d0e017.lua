function Global.SetScenarioPedsSpawnInSphereArea(x, y, z, range, p4)
	return _in(0x28157D43CF600981, x, y, z, range, p4)
end
