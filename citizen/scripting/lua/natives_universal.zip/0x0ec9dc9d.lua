--- console hash: 0xE8C0C629
function Global.N_0xccf1e97befdae480(entity)
	return _in(0xCCF1E97BEFDAE480, entity, _r)
end
