--- Console Hash 0xF4287778 = NETWORK_SPENT_REQUEST_HEIST
function Global.NetworkSpentRequestHeist(p0, p1, p2)
	return _in(0x9D26502BB97BFE62, p0, p1, p2)
end
