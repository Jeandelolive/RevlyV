--- Inhibits the player from using any method of combat including melee and firearms.
-- NOTE: Only disables the firing for one frame
function Global.DisablePlayerFiring(player, toggle)
	return _in(0x5E6CC07646BBEAB8, player, toggle)
end
